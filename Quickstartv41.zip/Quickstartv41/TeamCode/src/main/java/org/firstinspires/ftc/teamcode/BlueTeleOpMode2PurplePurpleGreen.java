package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.VoltageSensor;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

import java.util.ArrayList;
import java.util.List;

@TeleOp(name = "Blue Purple-Purple-Green", group = "TeleOp")
public class BlueTeleOpMode2PurplePurpleGreen extends LinearOpMode {

    private DcMotor frontLeft, frontRight, backLeft, backRight;
    private DcMotor s1, s2, fi;
    private Servo ha;
    private CRServo tl, tr;
    private Servo armLeft, armBack, armRight;
    private ColorSensor leftCs, backCs, rightCs;
    private GoBildaPinpointDriver pinpoint;
    private Limelight3A limelight;
    private VoltageSensor voltageSensor;

    private double hoodPos = 0.4;
    private final double HOOD_MIN = 0.3;
    private final double HOOD_MAX = 0.9;
    private final double HOOD_STEP = 0.1;

    private static final double NOMINAL_VOLTAGE = 12.0;
    private double voltageCompensation = 1.0;

    long shooterStartTime = 0;
    boolean shooterActive = false;
    boolean shooterSpunUp = false;
    boolean autoRamping = false;
    long lastDetectionTime = 0;
    boolean wasDetecting = false;

    final long SPINUP_TIME_MS = 1450;
    final long BOOST_TIME_MS = 450;
    final long KEEP_ALIVE_TIME_MS = 5000;

    final int COLOR_DETECT_THRESHOLD = 100;

    private final String[] priorityOrder = {"Purple", "Purple", "Green"};
    private List<String> armsToLift = new ArrayList<>();
    private int sequenceStep = 0;
    private boolean sequenceActive = false;
    private long armMoveStartTime = 0;
    private final long ARM_MOVE_DELAY = 600;
    private boolean armLifted = false;

    boolean lastX = false, lastY = false;

    private static final int TARGET_TAG_ID = 20;
    private static final double TRACK_DEADZONE = 1.5;
    private static final double TRACK_MAX_SPEED = 0.3;
    private static final double TRACK_MIN_SPEED = 0.05;
    private static final double TRACK_KP = 0.015;
    private static final double TRACK_OFFSET = -3.0;

    // Rotation multiplier for turning
    private static final double ROTATION_MULTIPLIER = 1.5;

    @Override
    public void runOpMode() {

        frontLeft  = hardwareMap.get(DcMotor.class, "fl");
        frontRight = hardwareMap.get(DcMotor.class, "fr");
        backLeft   = hardwareMap.get(DcMotor.class, "bl");
        backRight  = hardwareMap.get(DcMotor.class, "br");

        s1 = hardwareMap.get(DcMotor.class, "s1");
        s2 = hardwareMap.get(DcMotor.class, "s2");
        fi = hardwareMap.get(DcMotor.class, "fi");

        ha = hardwareMap.get(Servo.class, "ha");
        tl = hardwareMap.get(CRServo.class, "tl");
        tr = hardwareMap.get(CRServo.class, "tr");

        armLeft  = hardwareMap.get(Servo.class, "al");
        armBack  = hardwareMap.get(Servo.class, "ab");
        armRight = hardwareMap.get(Servo.class, "ar");

        leftCs  = hardwareMap.get(ColorSensor.class, "leftCs");
        backCs  = hardwareMap.get(ColorSensor.class, "backCs");
        rightCs = hardwareMap.get(ColorSensor.class, "rightCs");

        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "pinpoint");
        configurePinpoint();

        voltageSensor = hardwareMap.voltageSensor.iterator().next();

        for (Limelight3A ll : hardwareMap.getAll(Limelight3A.class)) {
            limelight = ll;
            break;
        }
        if (limelight != null) {
            limelight.pipelineSwitch(1);
            limelight.start();
        }

        frontLeft.setDirection(DcMotor.Direction.FORWARD);
        backLeft.setDirection(DcMotor.Direction.FORWARD);
        frontRight.setDirection(DcMotor.Direction.REVERSE);
        backRight.setDirection(DcMotor.Direction.REVERSE);

        // Set motor modes for max speed
        frontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        frontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        s1.setDirection(DcMotor.Direction.REVERSE);
        s2.setDirection(DcMotor.Direction.REVERSE);
        fi.setDirection(DcMotor.Direction.REVERSE);

        ha.setPosition(0.4);
        armLeft.setPosition(.9);
        armBack.setPosition(1);
        armRight.setPosition(1);

        waitForStart();

        while (opModeIsActive()) {

            updateVoltageCompensation();

            // ---- DRIVE ----
            double y  = -gamepad1.left_stick_y;
            double x  = -gamepad1.left_stick_x;
            double rx =  gamepad1.right_stick_x * ROTATION_MULTIPLIER;

            double fl = y + x + rx;
            double fr = y - x - rx;
            double bl = y - x + rx;
            double br = y + x - rx;

            double max = Math.max(Math.abs(fl),
                    Math.max(Math.abs(fr), Math.max(Math.abs(bl), Math.abs(br))));
            if (max > 1.0) {
                fl /= max; fr /= max; bl /= max; br /= max;
            }

            // No voltage compensation on drive motors
            frontLeft.setPower(fl);
            frontRight.setPower(fr);
            backLeft.setPower(bl);
            backRight.setPower(br);

            // ---- HOOD ----
            if (gamepad1.x && !lastX) hoodPos += HOOD_STEP;
            if (gamepad1.y && !lastY) hoodPos -= HOOD_STEP;
            hoodPos = Math.max(HOOD_MIN, Math.min(HOOD_MAX, hoodPos));
            ha.setPosition(hoodPos);
            lastX = gamepad1.x;
            lastY = gamepad1.y;

            // ---- TURRET ----
            boolean manualTurret = gamepad1.dpad_left || gamepad1.dpad_right;

            if (manualTurret) {
                double p = 0.5;
                if (gamepad1.dpad_left) {
                    tl.setPower(-p);
                    tr.setPower(-p);
                } else if (gamepad1.dpad_right) {
                    tl.setPower(p);
                    tr.setPower(p);
                } else {
                    tl.setPower(0);
                    tr.setPower(0);
                }
            } else {
                autoTrackAprilTag();
            }
            // ---- INTAKE ----
            if (gamepad2.x) fi.setPower(1);
            else if (gamepad2.y) fi.setPower(-1);
            else fi.setPower(0);

            // ---- COLOR DETECTION ----
            String leftColor  = detectBallColor(leftCs);
            String backColor  = detectBallColor(backCs);
            String rightColor = detectBallColor(rightCs);

            // ---- ARM SEQUENCE ----
            if (gamepad2.dpad_up && !sequenceActive) {
                buildArmSequence();
                if (!armsToLift.isEmpty()) {
                    sequenceActive = true;
                    sequenceStep = 0;
                    armLifted = false;
                    armMoveStartTime = System.currentTimeMillis();
                }
            }

            if (sequenceActive) processArmSequence();

            // ---- SHOOTER ----
            boolean detected = detectObject();
            if (detected) {
                lastDetectionTime = System.currentTimeMillis();
                wasDetecting = true;
            }

            long dt = System.currentTimeMillis() - lastDetectionTime;
            boolean keepAlive = wasDetecting && dt < KEEP_ALIVE_TIME_MS;

            double target = 0;
            if (gamepad2.a) target = 0.55;
            else if (gamepad2.b) target = 0.4;
            else if (detected || keepAlive) target = 0.45;

            double power = 0;
            if (target > 0) {
                if (!shooterActive) {
                    shooterStartTime = System.currentTimeMillis();
                    shooterActive = true;
                    shooterSpunUp = false;
                }
                long elapsed = System.currentTimeMillis() - shooterStartTime;
                power = (elapsed < BOOST_TIME_MS) ? 1.0 : target;
                if (!shooterSpunUp && elapsed > SPINUP_TIME_MS) {
                    shooterSpunUp = true;
                    gamepad2.rumble(1, 1, 500);
                }
            } else {
                shooterActive = false;
                shooterSpunUp = false;
            }

            // Voltage compensation ONLY on shooter motors
            s1.setPower(applyVoltageComp(power));
            s2.setPower(applyVoltageComp(power));

            // ---- TELEMETRY ----
            telemetry.addData("LEFT RGB",  "R:%d G:%d B:%d A:%d",
                    leftCs.red(), leftCs.green(), leftCs.blue(), leftCs.alpha());
            telemetry.addData("BACK RGB",  "R:%d G:%d B:%d A:%d",
                    backCs.red(), backCs.green(), backCs.blue(), backCs.alpha());
            telemetry.addData("RIGHT RGB", "R:%d G:%d B:%d A:%d",
                    rightCs.red(), rightCs.green(), rightCs.blue(), rightCs.alpha());

            telemetry.addData("Detected Left", leftColor);
            telemetry.addData("Detected Back", backColor);
            telemetry.addData("Detected Right", rightColor);
            telemetry.addData("Sequence", armsToLift.toString());
            telemetry.addData("Shooter Power", power);
            telemetry.update();
        }
    }

    // ---------- HELPERS ----------

    private void updateVoltageCompensation() {
        voltageCompensation = NOMINAL_VOLTAGE / voltageSensor.getVoltage();
    }

    private double applyVoltageComp(double power) {
        return Math.max(-1, Math.min(1, power * voltageCompensation));
    }

    private boolean detectObject() {
        return leftCs.alpha() > COLOR_DETECT_THRESHOLD ||
                backCs.alpha() > COLOR_DETECT_THRESHOLD ||
                rightCs.alpha() > COLOR_DETECT_THRESHOLD;
    }

    // 🔥 UNKNOWN = PURPLE
    private String detectBallColor(ColorSensor s) {
        if (s.alpha() < COLOR_DETECT_THRESHOLD) return "None";
        if (s.green() > s.red() && s.green() > s.blue()) return "Green";
        return "Purple";
    }

    private void buildArmSequence() {
        armsToLift.clear();

        String l = detectBallColor(leftCs);
        String b = detectBallColor(backCs);
        String r = detectBallColor(rightCs);

        List<String> avail = new ArrayList<>();
        if (!l.equals("None")) avail.add("left:" + l);
        if (!b.equals("None")) avail.add("back:" + b);
        if (!r.equals("None")) avail.add("right:" + r);

        for (String p : priorityOrder) {
            for (int i = 0; i < avail.size(); i++) {
                if (avail.get(i).endsWith(p)) {
                    armsToLift.add(avail.get(i).split(":")[0]);
                    avail.remove(i);
                    break;
                }
            }
        }
        for (String a : avail) armsToLift.add(a.split(":")[0]);
    }

    private void liftArm(String a) {
        if (a.equals("left")) armLeft.setPosition(0.3);
        if (a.equals("back")) armBack.setPosition(0.3);
        if (a.equals("right")) armRight.setPosition(0.3);
    }

    private void lowerArm(String a) {
        if (a.equals("left")) armLeft.setPosition(.9);
        if (a.equals("back")) armBack.setPosition(1);
        if (a.equals("right")) armRight.setPosition(1);
    }

    private void processArmSequence() {
        long t = System.currentTimeMillis() - armMoveStartTime;
        if (sequenceStep >= armsToLift.size()) {
            sequenceActive = false;
            armsToLift.clear();
            return;
        }
        String arm = armsToLift.get(sequenceStep);
        if (!armLifted && t > ARM_MOVE_DELAY) {
            liftArm(arm);
            armLifted = true;
            armMoveStartTime = System.currentTimeMillis();
        } else if (armLifted && t > ARM_MOVE_DELAY) {
            lowerArm(arm);
            sequenceStep++;
            armLifted = false;
            armMoveStartTime = System.currentTimeMillis();
        }
    }

    private void autoTrackAprilTag() {
        if (limelight == null) {
            tl.setPower(0);
            tr.setPower(0);
            return;
        }

        LLResult r = limelight.getLatestResult();
        if (r == null || !r.isValid()) {
            tl.setPower(0);
            tr.setPower(0);
            return;
        }

        boolean tagFound = false;
        for (LLResultTypes.FiducialResult t : r.getFiducialResults()) {
            if (t.getFiducialId() == TARGET_TAG_ID) {
                tagFound = true;
                double tx = t.getTargetXDegrees() + TRACK_OFFSET;

                if (Math.abs(tx) < TRACK_DEADZONE) {
                    tl.setPower(0);
                    tr.setPower(0);
                } else {
                    double sp = Math.signum(tx) *
                            Math.min(TRACK_MAX_SPEED,
                                    Math.max(TRACK_MIN_SPEED, Math.abs(tx * TRACK_KP)));
                    tl.setPower(sp);
                    tr.setPower(sp);
                }
                break;
            }
        }

        // Stop if tag wasn't found
        if (!tagFound) {
            tl.setPower(0);
            tr.setPower(0);
        }
    }

    private void configurePinpoint() {
        pinpoint.setOffsets(0, 0, DistanceUnit.MM);
        pinpoint.setEncoderResolution(
                GoBildaPinpointDriver.GoBildaOdometryPods.goBILDA_4_BAR_POD);
        pinpoint.setEncoderDirections(
                GoBildaPinpointDriver.EncoderDirection.FORWARD,
                GoBildaPinpointDriver.EncoderDirection.FORWARD);
        pinpoint.resetPosAndIMU();
    }
}